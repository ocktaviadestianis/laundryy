-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 09, 2018 at 08:09 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `laundry`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambil`
--

CREATE TABLE `ambil` (
  `nomor_antrian` int(11) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `jam` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `parfum` varchar(20) NOT NULL,
  `berat` int(5) NOT NULL,
  `jumlah` int(5) NOT NULL,
  `harga` int(9) NOT NULL,
  `tgl_keluar` varchar(20) NOT NULL,
  `jam_keluar` varchar(20) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ambil`
--

INSERT INTO `ambil` (`nomor_antrian`, `tanggal`, `jam`, `nama`, `parfum`, `berat`, `jumlah`, `harga`, `tgl_keluar`, `jam_keluar`, `bayar`, `kembalian`) VALUES
(1, '07/05/2018', '10:42:14', 'ww', 'Mawar', 2, 3, 14000, '08/05/2018', '15:01:37', 15000, 1000),
(2, '07/05/2018', '13:00:39', 'om', 'Apel', 2, 3, 24000, '08/05/2018', '14:26:57', 50000, 26000),
(3, '08/05/2018', '15:15:50', 'reta', 'Leci', 1, 2, 12000, '08/05/2018', '15:16:02', 15000, 3000),
(4, '08/05/2018', '15:18:22', 'ubed', 'Apel', 2, 12, 24000, '08/05/2018', '15:20:31', 30000, 6000),
(5, '08/05/2018', '15:19:24', 'desti', 'Apel', 3, 2, 36000, '08/05/2018', '15:38:01', 50000, 14000),
(6, '08/05/2018', '15:40:34', 'putri', 'Anggur', 1, 4, 12000, '08/05/2018', '15:40:52', 15000, 3000),
(7, '08/05/2018', '16:06:42', 'iyaa', 'Leci', 1, 3, 12000, '08/05/2018', '16:10:48', 15000, 3000);

-- --------------------------------------------------------

--
-- Stand-in structure for view `jadi`
-- (See below for the actual view)
--
CREATE TABLE `jadi` (
`tgl_keluar` varchar(20)
,`jam_keluar` varchar(20)
,`nomor_antrian` int(8)
,`tanggal` varchar(15)
,`jam` varchar(15)
,`nama` varchar(20)
,`parfum` varchar(20)
,`berat` int(3)
,`jumlah` int(3)
,`harga` int(10)
);

-- --------------------------------------------------------

--
-- Table structure for table `pembeli`
--

CREATE TABLE `pembeli` (
  `nomor_antrian` int(8) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `alamat` varchar(30) NOT NULL,
  `no_tlp` int(13) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembeli`
--

INSERT INTO `pembeli` (`nomor_antrian`, `nama`, `alamat`, `no_tlp`) VALUES
(1, 'jm', 'cicago', 856);

-- --------------------------------------------------------

--
-- Table structure for table `transaksi`
--

CREATE TABLE `transaksi` (
  `nomor_antrian` int(8) NOT NULL,
  `tanggal` varchar(15) NOT NULL,
  `jam` varchar(15) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `parfum` varchar(20) NOT NULL,
  `berat` int(3) NOT NULL,
  `jumlah` int(3) NOT NULL,
  `harga` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaksi`
--

INSERT INTO `transaksi` (`nomor_antrian`, `tanggal`, `jam`, `nama`, `parfum`, `berat`, `jumlah`, `harga`) VALUES
(8, '08/05/2018', '16:11:42', 'jm', 'Apel', 1, 1, 12000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`) VALUES
('admin', 'admin123');

-- --------------------------------------------------------

--
-- Structure for view `jadi`
--
DROP TABLE IF EXISTS `jadi`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `jadi`  AS  select `ambil`.`tgl_keluar` AS `tgl_keluar`,`ambil`.`jam_keluar` AS `jam_keluar`,`transaksi`.`nomor_antrian` AS `nomor_antrian`,`transaksi`.`tanggal` AS `tanggal`,`transaksi`.`jam` AS `jam`,`transaksi`.`nama` AS `nama`,`transaksi`.`parfum` AS `parfum`,`transaksi`.`berat` AS `berat`,`transaksi`.`jumlah` AS `jumlah`,`transaksi`.`harga` AS `harga` from (`ambil` join `transaksi` on((`ambil`.`nomor_antrian` = `transaksi`.`nomor_antrian`))) ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambil`
--
ALTER TABLE `ambil`
  ADD PRIMARY KEY (`nomor_antrian`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`nomor_antrian`);

--
-- Indexes for table `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`nomor_antrian`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `nomor_antrian` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaksi`
--
ALTER TABLE `transaksi`
  MODIFY `nomor_antrian` int(8) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
